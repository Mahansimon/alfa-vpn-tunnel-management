#!/usr/bin/env bash
# ============================================================================
#  BrokenNode Tunnel - Manager (prebuilt core, no build / no internet)
#  Multi-instance | presets | per-port tcp/udp/both | systemd
#  Transport 11 = ip-spoofing (built into the core; same config/passkey/unit)
# ============================================================================
set -uo pipefail

VERSION="1.10.8"
BIN="/usr/local/bin/brokennode"
CFG_DIR="/etc/brokennode"
TPL="/etc/systemd/system/brokennode@.service"
UPDATE_CONF="/etc/brokennode/update.conf"
AU_SVC="/etc/systemd/system/brokennode-autoupdate.service"
AU_TIMER="/etc/systemd/system/brokennode-autoupdate.timer"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

C_R='\033[0;31m'; C_G='\033[0;32m'; C_Y='\033[1;33m'; C_B='\033[0;36m'; C_M='\033[0;35m'; C_D='\033[0;90m'; C_N='\033[0m'
info(){ echo -e "${C_G}  [+]${C_N} $*"; }
warn(){ echo -e "${C_Y}  [!]${C_N} $*"; }
err(){ echo -e "${C_R}  [x]${C_N} $*" >&2; }
ask(){ local p="$1" d="${2:-}" a; if [ -n "$d" ]; then read -rp "$(echo -e "${C_B}  ?${C_N} $p [${C_D}$d${C_N}]: ")" a; echo "${a:-$d}"; else read -rp "$(echo -e "${C_B}  ?${C_N} $p: ")" a; echo "$a"; fi; }
need_root(){ [ "$(id -u)" -eq 0 ] || { err "Run as root: sudo bash BrokenNode.sh"; exit 1; }; }
detect_ip(){ ip -4 route get 8.8.8.8 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}' | head -1 || true; }

core_ver(){ if [ -x "$BIN" ]; then "$BIN" version 2>/dev/null | awk '{print $NF}'; else echo "v$VERSION"; fi; }
banner(){
  clear 2>/dev/null || true
  local v; v="$(core_ver)"
  echo -e "${C_M}"
  echo "  ╔══════════════════════════════════════════════╗"
  echo "  ║           B R O K E N   N O D E              ║"
  printf "  ║      Multi-Protocol Tunnel  ·  %-14s║\n" "$v"
  echo "  ╠══════════════════════════════════════════════╣"
  printf "  ║%-46s║\n" "      Telegram:  @BrokenNode"
  echo "  ╚══════════════════════════════════════════════╝"
  echo -e "${C_N}${C_D}  arch: $(uname -m)   manager: v$VERSION   core: $([ -x "$BIN" ] && core_ver || echo 'not installed')${C_N}"
  echo -e "${C_G}  Free & open-source · t.me/BrokenNode${C_N}"
}

arch_sfx(){ case "$(uname -m)" in x86_64|amd64) echo amd64;; aarch64|arm64) echo arm64;; *) echo amd64;; esac; }
detect_bin(){ local f="$SRC_DIR/brokennode-linux-$(arch_sfx)"; [ -f "$f" ] && echo "$f" || { [ -f "$SRC_DIR/brokennode" ] && echo "$SRC_DIR/brokennode"; }; }
install_core(){
  need_root; local src; src="$(detect_bin)"
  [ -n "$src" ] && [ -f "$src" ] || { err "No binary for $(uname -m) next to this script."; return 1; }
  install -m0755 "$src" "$BIN"; info "Core installed: $("$BIN" version)"
}
ensure_core(){
  local src; src="$(detect_bin)"
  if [ -n "$src" ] && [ -f "$src" ]; then
    { [ ! -x "$BIN" ] || ! cmp -s "$src" "$BIN"; } && { install -m0755 "$src" "$BIN"; info "Core updated: $("$BIN" version)"; }
    return 0
  fi
  [ -x "$BIN" ] && return 0
  err "No binary next to script and none installed."; return 1
}

write_template(){
  cat > "$TPL" <<EOF
[Unit]
Description=BrokenNode Tunnel (%i)
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
ExecStart=$BIN -c $CFG_DIR/%i.json
Restart=always
RestartSec=2
# No resource ceilings: the tunnel may use as much CPU / RAM / sockets as the
# box has. Raise nothing artificially; the OS hard limits are the only cap.
LimitNOFILE=infinity
LimitNPROC=infinity
LimitMEMLOCK=infinity
TasksMax=infinity
[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
}
gen_token(){ ( head -c 24 /dev/urandom | base64 2>/dev/null | tr -d '/+=' | head -c 24 ) || echo "bn$(date +%s)$RANDOM"; }

pick_transport(){
  echo >&2
  echo -e "${C_B}  Select transport:${C_N}" >&2
  echo -e "  ${C_D}──────────────────────────────────────────────${C_N}" >&2
  echo -e "   1) tcp       Plain TCP + smux         ${C_G}(stable baseline)${C_N}" >&2
  echo -e "   2) tcpobf    TCP + obfuscation        ${C_G}(anti-DPI)${C_N}" >&2
  echo -e "   3) mtcp      Multi-link TCP           ${C_G}(beats throttling)${C_N}" >&2
  echo -e "   4) mtcpobf   Multi-link + obfuscation ${C_G}(best for Iran)${C_N}" >&2
  echo    "   5) ws        WebSocket/HTTP + smux    (HTTP mimicry)" >&2
  echo    "   6) wsobf     WebSocket + obfuscation  (HTTP look, random payload)" >&2
  echo    "   7) tcpnomux  TCP pool, no HoL         (heavy single-flow)" >&2
  echo -e "   8) kcp       KCP/UDP + FEC            ${C_Y}(only if UDP works)${C_N}" >&2
  echo -e "   9) rawmux    KCP/UDP + obfuscation    ${C_Y}(only if UDP works)${C_N}" >&2
  echo -e "  10) quic      QUIC/UDP, no HoL         ${C_Y}(only if UDP works)${C_N}" >&2
  echo -e "  11) quicd     QUIC: TCP=streams, UDP=datagrams ${C_G}(best for gaming)${C_N} ${C_Y}(UDP only)${C_N}" >&2
  echo -e "  12) ip-spoofing  Spoofed-IP TUN        ${C_M}(blackout / national whitelist)${C_N}" >&2
  echo -e "  ${C_D}──────────────────────────────────────────────${C_N}" >&2
  local n; n=$(ask "Choice [1-12]" "1")
  case "$n" in
    1) echo tcp ;; 2) echo tcpobf ;; 3) echo mtcp ;; 4) echo mtcpobf ;;
    5) echo ws ;; 6) echo wsobf ;; 7) echo tcpnomux ;; 8) echo kcp ;;
    9) echo rawmux ;; 10) echo quic ;; 11) echo quicd ;; 12) echo spoof ;; *) echo tcp ;;
  esac
}

pick_preset(){
  echo >&2
  echo -e "${C_B}  Connection preset:${C_N}" >&2
  echo    "   1) Optimized    balanced (Recommended)" >&2
  echo    "   2) High-Speed   max throughput" >&2
  echo    "   3) Stable       tolerate high packet loss" >&2
  echo    "   4) Low-Latency  gaming / VoIP" >&2
  echo    "   5) Eco          low CPU/RAM, weak VPS" >&2
  local n; n=$(ask "Choice [1-5]" "1")
  case "$n" in 2) echo "15 turbo 10 2";; 3) echo "8 normal 10 4";; 4) echo "5 gaming 10 4";; 5) echo "20 normal 10 1";; *) echo "10 fast 10 3";; esac
}

build_ports(){
  local arr=() spec proto sfx
  echo -e "${C_B}  Port mappings${C_N} ${C_D}(formats: 443 | 8443=443 ; empty to finish)${C_N}" >&2
  while true; do
    spec=$(ask "Port(s) (empty=done)" ""); [ -z "$spec" ] && break
    proto=$(ask "Protocol  1)tcp 2)udp 3)both" "3")
    case "$proto" in 1) sfx="";; 2) sfx="/udp";; *) sfx="/both";; esac
    arr+=("\"${spec}${sfx}\""); echo -e "${C_G}    added ${spec}${sfx}${C_N}" >&2
  done
  [ ${#arr[@]} -eq 0 ] && arr+=("\"443/both\""); ( IFS=,; echo "${arr[*]}" )
}

build_extra(){ local role="$1" tr="$2"; EXTRA=""; TLSJSON=""
  case "$tr" in
    ws|wsobf)
      EXTRA="\"ws_path\":\"$(ask 'WebSocket path' '/')\","
      if [ "$role" = client ]; then
        local h u; h=$(ask 'Fake Host header (domain fronting, empty=none)' '')
        u=$(ask 'User-Agent (empty=default)' '')
        [ -n "$h" ] && EXTRA="$EXTRA\"ws_host\":\"$h\","
        [ -n "$u" ] && EXTRA="$EXTRA\"ws_user_agent\":\"$u\","
      fi ;;
    quic|quicd) EXTRA="\"alpn\":\"$(ask 'ALPN' 'h3')\",";;
    tcpnomux) EXTRA="\"pool_size\":$(ask 'Connection pool size (0 = AUTO, scales with load — recommended)' '0'),";;
    kcp|rawmux)
      local w; w=$(ask 'KCP window (send/recv, empty=1024)' '')
      [ -n "$w" ] && EXTRA="\"kcp_sndwnd\":$w,\"kcp_rcvwnd\":$w," ;;
    mtcp|mtcpobf) [ "$role" = client ] && EXTRA="\"links\":$(ask 'Parallel links (0 = AUTO, scales with load — recommended)' '0'),";;
  esac
}

# spoof transport: collect spoof_* fields, write a NORMAL JSON config (transport=spoof)
write_spoof_cfg(){
  local role="$1" name="$2" cfg="$CFG_DIR/$name.json"
  echo -e "${C_B}  Spoof carrier protocol:${C_N}" >&2
  echo    "   1) udp    (tested, recommended)" >&2
  echo -e "   2) tcp    fake-TCP ${C_Y}(untested)${C_N}" >&2
  echo -e "   3) icmp   echo      ${C_Y}(untested)${C_N}" >&2
  echo -e "   4) gre    IP proto 47 ${C_Y}(untested; often whitelisted)${C_N}" >&2
  local pn cproto; pn=$(ask "Choice [1-4]" "1"); case "$pn" in 2) cproto=tcp;; 3) cproto=icmp;; 4) cproto=gre;; *) cproto=udp;; esac
  echo -e "  ${C_D}Enter the SAME IPs on BOTH servers; cross-over is automatic.${C_N}" >&2
  local det iran foreign w1 w2; det=$(detect_ip)
  if [ "$role" = server ]; then
    iran=$(ask "Iran IP    (this machine, real)" "$det")
    foreign=$(ask "Foreign IP (peer, real)" "")
  else
    foreign=$(ask "Foreign IP (this machine, real)" "$det")
    iran=$(ask "Iran IP    (peer, real)" "")
  fi
  w1=$(ask "White IP #1 — the one IRAN sends as source" "")
  w2=$(ask "White IP #2 — the one FOREIGN sends as source" "")
  local cport mtu jit jjson; cport=$(ask "Carrier port (udp/tcp)" "6262"); mtu=$(ask "MTU" "1320")
  jit=$(ask "TTL jitter? (anti-fingerprint) y/N" "N")
  local jline jtail; case "$jit" in y|Y) jline='
  "ttl_jitter": true,'; jtail=',
  "ttl_jitter": true';; *) jline=''; jtail='';; esac
  local lip pip ssrc sdst tl trr
  if [ "$role" = server ]; then
    lip="$iran"; pip="$foreign"; ssrc="$w1"; sdst="$w2"; tl=10.10.20.1; trr=10.10.20.2
  else
    lip="$foreign"; pip="$iran"; ssrc="$w2"; sdst="$w1"; tl=10.10.20.2; trr=10.10.20.1
  fi
  local portsjson="" pk
  if [ "$role" = server ]; then
    portsjson=$(build_ports)
    pk=$(ask "Passkey from the bot (BNK1-...; empty if already set)" "")
    [ -n "$pk" ] && { printf '%s\n' "$pk" > "$CFG_DIR/passkey"; chmod 600 "$CFG_DIR/passkey"; info "Passkey saved to $CFG_DIR/passkey"; }
  fi
  if [ "$role" = server ]; then
    cat > "$cfg" <<EOF
{
  "mode": "server",
  "transport": "spoof",
  "log_level": "info",
  "spoof_local_ip": "$lip",
  "spoof_peer_ip": "$pip",
  "spoof_src": "$ssrc",
  "spoof_dst": "$sdst",
  "carrier_proto": "$cproto",
  "carrier_port": $cport,
  "tun_name": "spoof0",
  "tun_local": "$tl",
  "tun_remote": "$trr",
  "mtu": $mtu,$jline
  "ports": [$portsjson]
}
EOF
  else
    cat > "$cfg" <<EOF
{
  "mode": "client",
  "transport": "spoof",
  "log_level": "info",
  "spoof_local_ip": "$lip",
  "spoof_peer_ip": "$pip",
  "spoof_src": "$ssrc",
  "spoof_dst": "$sdst",
  "carrier_proto": "$cproto",
  "carrier_port": $cport,
  "tun_name": "spoof0",
  "tun_local": "$tl",
  "tun_remote": "$trr",
  "mtu": $mtu$jtail
}
EOF
  fi
  info "Saved $cfg"
  echo -e "  ${C_D}  proto=$cproto  spoof_src=$ssrc  spoof_dst=$sdst${C_N}"
}

create_tunnel(){
  need_root; ensure_core || return; mkdir -p "$CFG_DIR"; write_template
  local role="$1" name tr ka kmode kdata kparity
  echo; info "Create ${role^^} tunnel"
  name=$(ask "Instance name" "main"); name="$(echo "$name" | tr -cd 'A-Za-z0-9_-')"; [ -z "$name" ] && name=main
  if [ -f "$CFG_DIR/$name.json" ]; then local o; o=$(ask "'$name' exists. Overwrite? y/N" "N"); case "$o" in y|Y) :;; *) warn "Cancelled."; return;; esac; fi
  tr=$(pick_transport)

  if [ "$tr" = spoof ]; then
    write_spoof_cfg "$role" "$name"
  else
    read -r ka kmode kdata kparity <<< "$(pick_preset)"; build_extra "$role" "$tr"
    local cfg="$CFG_DIR/$name.json"
    if [ "$role" = server ]; then
      local bind ports token pk
      bind=$(ask "Tunnel listen address (host:port)" "0.0.0.0:8443"); ports=$(build_ports)
      token=$(ask "Shared token" "$(gen_token)")
      pk=$(ask "Passkey from the bot (BNK1-...; leave empty if already set)" "")
      [ -n "$pk" ] && { printf '%s\n' "$pk" > "$CFG_DIR/passkey"; chmod 600 "$CFG_DIR/passkey"; info "Passkey saved to $CFG_DIR/passkey"; }
      cat > "$cfg" <<EOF
{
  "mode": "server",
  "transport": "$tr",
  "token": "$token",
  "bind_addr": "$bind",
  "ports": [$ports],
  $TLSJSON$EXTRA
  "keepalive": $ka,
  "kcp_mode": "$kmode", "kcp_data": $kdata, "kcp_parity": $kparity,
  "log_level": "info"
}
EOF
      info "Saved $cfg"; warn "Token for the client: ${C_Y}$token${C_N}"
    else
      local remote token target
      remote=$(ask "Tunnel server address (Iran relay IP:port)" "1.2.3.4:8443")
      token=$(ask "Shared token (same as server)" ""); target=$(ask "Local services host" "127.0.0.1")
      cat > "$cfg" <<EOF
{
  "mode": "client",
  "transport": "$tr",
  "token": "$token",
  "remote_addr": "$remote",
  "target_host": "$target",
  $EXTRA
  "keepalive": $ka,
  "kcp_mode": "$kmode", "kcp_data": $kdata, "kcp_parity": $kparity,
  "log_level": "info"
}
EOF
      info "Saved $cfg"
    fi
  fi

  systemctl enable "brokennode@$name" >/dev/null 2>&1; systemctl restart "brokennode@$name"; sleep 1.5
  if [ "$(systemctl is-active "brokennode@$name" 2>/dev/null)" = active ]; then info "Tunnel '$name' is ${C_G}active${C_N}."
  else err "Tunnel '$name' failed to start. Recent log:"; journalctl -u "brokennode@$name" -n 10 --no-pager 2>/dev/null | sed 's/^/    /'; fi
}

list_tunnels(){
  TUNNELS=()
  local f n st any=0 i=0
  echo; echo -e "${C_B}  Tunnels:${C_N}"
  echo -e "  ${C_D}──────────────────────────────────────────────${C_N}"
  for f in "$CFG_DIR"/*.json; do
    [ -e "$f" ] || continue
    any=1; n="$(basename "$f" .json)"; i=$((i+1)); TUNNELS+=("$n")
    st="$(systemctl is-active "brokennode@$n" 2>/dev/null)"
    local m tr; m=$(grep -o '"mode"[^,]*' "$f" | sed 's/.*: *"//;s/".*//'); tr=$(grep -o '"transport"[^,]*' "$f" | sed 's/.*: *"//;s/".*//')
    local col="$C_R"; [ "$st" = active ] && col="$C_G"
    printf "  %2d) %-14s ${col}%-8s${C_N} ${C_D}%s/%s${C_N}\n" "$i" "$n" "$st" "$m" "$tr"
  done
  [ "$any" = 0 ] && echo -e "   ${C_D}(no tunnels yet)${C_N}"
  echo -e "  ${C_D}──────────────────────────────────────────────${C_N}"
}

hb(){ # humanize bytes -> KB/MB/GB/TB
  local b="${1:-0}"; awk -v b="$b" 'BEGIN{
    u="B"; x=b+0;
    if(x>=1024){x/=1024;u="KB"} if(x>=1024){x/=1024;u="MB"} if(x>=1024){x/=1024;u="GB"} if(x>=1024){x/=1024;u="TB"}
    if(u=="B")printf "%d%s",x,u; else printf "%.2f%s",x,u }'
}

# live_logs: follow ONLY the current run (since last start), live, and let Ctrl+C
# return to the menu instead of killing the whole script.
live_logs(){
  local n="$1" unit="brokennode@$1"
  echo -e "${C_B}  Live logs: $n${C_N}   ${C_D}(Ctrl+C = back to menu)${C_N}"
  echo -e "  ${C_D}──────────────────────────────────────────────${C_N}"
  local since; since="$(systemctl show -p ActiveEnterTimestamp --value "$unit" 2>/dev/null)"
  trap ':' INT   # catch Ctrl+C here so the script is NOT terminated
  if [ -n "$since" ] && [ "$since" != "n/a" ]; then
    journalctl -u "$unit" -f --since "$since" -o short-precise 2>/dev/null
  else
    journalctl -u "$unit" -f -n 0 -o short-precise 2>/dev/null
  fi
  trap - INT     # restore
  echo -e "\n${C_G}  ← back to menu${C_N}"; sleep 0.3
}

# stats_page: live per-tunnel traffic (upload/download/total + connections),
# refreshed from the core's stats file. Ctrl+C returns to the menu.
stats_page(){
  local n="$1" unit="brokennode@$1" f="/var/lib/brokennode/$1.stats"
  trap ':' INT
  while true; do
    banner
    echo -e "${C_B}  Live stats: $n${C_N}   ${C_D}[$(systemctl is-active "$unit" 2>/dev/null)]  (Ctrl+C = back)${C_N}"
    echo -e "  ${C_D}──────────────────────────────────────────────${C_N}"
    if [ -f "$f" ]; then
      local lup ldown ltot sup sdown stot atcp audp peak conns ts age
      lup=$(sed -n 's/^life_up=//p' "$f");     ldown=$(sed -n 's/^life_down=//p' "$f");   ltot=$(sed -n 's/^life_total=//p' "$f")
      sup=$(sed -n 's/^sess_up=//p' "$f");     sdown=$(sed -n 's/^sess_down=//p' "$f");   stot=$(sed -n 's/^sess_total=//p' "$f")
      atcp=$(sed -n 's/^active_tcp=//p' "$f"); audp=$(sed -n 's/^active_udp=//p' "$f")
      peak=$(sed -n 's/^peak=//p' "$f");       conns=$(sed -n 's/^conns=//p' "$f");       ts=$(sed -n 's/^ts=//p' "$f")
      age=$(( $(date +%s) - ${ts:-0} ))
      echo -e "    ${C_B}Lifetime${C_N} ${C_D}(survives restarts & reboots)${C_N}"
      printf "      ↑ %s   ↓ %s   total %s\n" "$(hb "${lup:-0}")" "$(hb "${ldown:-0}")" "$(hb "${ltot:-0}")"
      echo -e "    ${C_B}This session${C_N}"
      printf "      ↑ %s   ↓ %s   total %s\n" "$(hb "${sup:-0}")" "$(hb "${sdown:-0}")" "$(hb "${stot:-0}")"
      echo -e "  ${C_D}──────────────────────────────────────────────${C_N}"
      printf "    Active connections : %s  (tcp %s, udp %s)\n" "$(( ${atcp:-0} + ${audp:-0} ))" "${atcp:-0}" "${audp:-0}"
      printf "    Peak / total seen  : %s / %s\n" "${peak:-0}" "${conns:-0}"
      echo -e "  ${C_D}  (updated ${age}s ago; core writes stats every 30s)${C_N}"
    else
      echo "    No stats yet — start the tunnel; the core writes stats every 30s."
    fi
    sleep 2
  done
  trap - INT
}

okln(){   echo -e "  ${C_G}✔${C_N} $*"; }
warnln(){ echo -e "  ${C_Y}▲${C_N} $*"; }
badln(){  echo -e "  ${C_R}✗${C_N} $*"; }

# doctor: one-shot self-diagnosis of the things that actually break tunnels
# (BBR, ports, UDP reachability, public IP, packet loss, MTU, services).
doctor(){
  banner
  echo -e "${C_B}  BrokenNode Doctor${C_N}   ${C_D}(read-only checks)${C_N}"
  echo -e "  ${C_D}──────────────────────────────────────────────${C_N}"
  local warns=0

  # Congestion control (BBR)
  local cc; cc="$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)"
  if [ "$cc" = bbr ]; then okln "Congestion control: bbr"
  else warnln "Congestion control: ${cc:-unknown} — run 'sudo bash BrokenNode.sh tune' for BBR"; warns=$((warns+1)); fi
  # qdisc
  local qd; qd="$(sysctl -n net.core.default_qdisc 2>/dev/null)"
  [ "$qd" = fq ] && okln "Queue discipline: fq" || { warnln "Queue discipline: ${qd:-unknown} (fq recommended)"; warns=$((warns+1)); }

  # Public IP
  local ip; ip="$(curl -s --max-time 6 https://api.ipify.org 2>/dev/null)"
  [ -z "$ip" ] && ip="$(curl -s --max-time 6 https://ipinfo.io/ip 2>/dev/null)"
  if printf '%s' "$ip" | grep -qE '^[0-9a-fA-F:.]+$' && printf '%s' "$ip" | grep -qE '[0-9]'; then
    okln "Public IP: $ip"
  else
    warnln "Public IP: could not determine (network/DNS?)"; warns=$((warns+1))
  fi

  # FD limit
  local fd; fd="$(ulimit -n)"
  okln "Open-file limit (ulimit -n): $fd"

  echo -e "  ${C_D}── per-tunnel ─────────────────────────────────${C_N}"
  shopt -s nullglob
  local found=0
  for cf in "$CFG_DIR"/*.json; do
    found=1
    local n; n="$(basename "$cf" .json)"
    local mode trans bind remote ports
    mode="$(sed -n 's/.*"mode"[ ]*:[ ]*"\([^"]*\)".*/\1/p' "$cf")"
    trans="$(sed -n 's/.*"transport"[ ]*:[ ]*"\([^"]*\)".*/\1/p' "$cf")"
    bind="$(sed -n 's/.*"bind_addr"[ ]*:[ ]*"\([^"]*\)".*/\1/p' "$cf")"
    remote="$(sed -n 's/.*"remote_addr"[ ]*:[ ]*"\([^"]*\)".*/\1/p' "$cf")"
    echo -e "  ${C_B}• $n${C_N} ${C_D}($mode/$trans)${C_N}"
    # service state
    local st; st="$(systemctl is-active "brokennode@$n" 2>/dev/null)"
    [ "$st" = active ] && okln "  service: active" || { badln "  service: $st"; warns=$((warns+1)); }

    if [ "$mode" = server ]; then
      local port; port="${bind##*:}"
      if [ -n "$port" ]; then
        ss -ltnup 2>/dev/null | grep -q ":$port " && okln "  listening on port $port" || { warnln "  port $port not listening"; warns=$((warns+1)); }
      fi
    else
      # client: measure path quality to the relay
      local host="${remote%%:*}"
      if [ -n "$host" ]; then
        local pres; pres="$(ping -c 5 -w 8 "$host" 2>/dev/null | tail -2)"
        local loss rtt
        loss="$(printf '%s' "$pres" | sed -n 's/.*, \([0-9.]*\)% packet loss.*/\1/p')"
        rtt="$(printf '%s' "$pres" | sed -n 's#.*= [0-9.]*/\([0-9.]*\)/.*#\1#p')"
        if [ -n "$loss" ]; then
          if awk "BEGIN{exit !(${loss:-0} > 3)}"; then warnln "  packet loss to $host: ${loss}% (high — hurts speed/latency)"; warns=$((warns+1));
          else okln "  packet loss to $host: ${loss}%"; fi
          [ -n "$rtt" ] && echo -e "  ${C_D}    avg RTT: ${rtt} ms${C_N}"
        else warnln "  could not ping $host (ICMP blocked?)"; fi
      fi
    fi
  done
  [ "$found" = 0 ] && echo "  (no tunnels configured yet)"
  echo -e "  ${C_D}──────────────────────────────────────────────${C_N}"
  if [ "$warns" -eq 0 ]; then echo -e "  ${C_G}All checks passed.${C_N}"
  else echo -e "  ${C_Y}$warns warning(s) above.${C_N}"; fi
  echo -e "  ${C_D}Note: UDP transports (kcp/quic) also need UDP open end-to-end;${C_N}"
  echo -e "  ${C_D}test with:  nc -u <relay-ip> <port>  (both sides).${C_N}"
}

manage_tunnels(){
  while true; do
    banner; list_tunnels
    if [ "${#TUNNELS[@]}" -eq 0 ]; then read -rp "  press enter..." _; return; fi
    local sel; sel=$(ask "Select tunnel number (empty=back)" ""); [ -z "$sel" ] && return
    case "$sel" in *[!0-9]*) err "Enter a number."; sleep 1; continue;; esac
    if [ "$sel" -lt 1 ] || [ "$sel" -gt "${#TUNNELS[@]}" ]; then err "Out of range."; sleep 1; continue; fi
    local n="${TUNNELS[$((sel-1))]}"
    local ED; ED="$(command -v nano || command -v vi)"
    while true; do
      echo; echo -e "${C_B}  Manage '$n'${C_N}  ${C_D}[$(systemctl is-active "brokennode@$n" 2>/dev/null)]${C_N}"
      echo "   1) Start    2) Stop    3) Restart"
      echo "   4) Live logs   5) Show config   6) Edit config (nano)"
      echo "   7) Delete   8) Live stats   0) Back"
      case "$(ask 'Choice' '')" in
        1) systemctl enable --now "brokennode@$n" >/dev/null 2>&1; systemctl start "brokennode@$n"; info "started";;
        2) systemctl stop "brokennode@$n"; info "stopped";;
        3) systemctl restart "brokennode@$n"; info "restarted";;
        4) live_logs "$n";;
        5) echo; cat "$CFG_DIR/$n.json"; echo; read -rp "  press enter..." _;;
        6) "${EDITOR:-$ED}" "$CFG_DIR/$n.json"; systemctl restart "brokennode@$n"; info "saved & restarted";;
        7) local c; c=$(ask "Delete '$n' permanently? yes/no" "no")
           if [ "$c" = yes ]; then systemctl disable --now "brokennode@$n" >/dev/null 2>&1; rm -f "$CFG_DIR/$n.json"; info "deleted '$n'"; break; fi;;
        8) stats_page "$n";;
        0) break;;
        *) warn "Invalid.";;
      esac
    done
  done
}

show_transports(){ banner; ensure_core && "$BIN" -transports; echo; read -rp "  press enter..." _; }

# restart_all_tunnels: refresh the unit and restart every configured instance.
restart_all_tunnels(){
  write_template
  systemctl daemon-reload 2>/dev/null
  local f n any=0
  for f in "$CFG_DIR"/*.json; do
    [ -e "$f" ] || continue
    any=1; n="$(basename "$f" .json)"
    systemctl enable "brokennode@$n" >/dev/null 2>&1
    systemctl restart "brokennode@$n"
    local st; st="$(systemctl is-active "brokennode@$n" 2>/dev/null)"
    [ "$st" = active ] && info "restarted brokennode@$n (${C_G}active${C_N})" || err "brokennode@$n -> $st"
  done
  [ "$any" = 0 ] && warn "No tunnels configured yet."
}

# update_all: install the binary that ships next to this script, then restart
# every tunnel WITHOUT touching any config.
update_all(){
  need_root
  local src; src="$(detect_bin)"
  [ -n "$src" ] && [ -f "$src" ] || { err "No new binary next to this script."; return 1; }
  install -m0755 "$src" "$BIN"; info "Core updated: $("$BIN" version)"
  restart_all_tunnels
  info "Update complete — all tunnels kept their config."
}

# auto_apply_bundled: run at startup. If the binary shipped next to the script
# differs from what's installed, install it and restart tunnels automatically —
# so customers never have to pick an "update" menu item. No-op when already
# up to date, or when not root.
auto_apply_bundled(){
  [ "$(id -u)" -eq 0 ] || return 0
  local src; src="$(detect_bin)"
  [ -n "$src" ] && [ -f "$src" ] || return 0
  if [ ! -x "$BIN" ] || ! cmp -s "$src" "$BIN"; then
    warn "New core bundled with this package — applying automatically..."
    install -m0755 "$src" "$BIN"; info "Core: $("$BIN" version)"
    restart_all_tunnels
    info "Auto-update done — configs untouched."
    read -rp "  press enter..." _ 2>/dev/null || true
  fi
}

# ---------------- remote (hands-off) auto-update ----------------
fetch(){ local u="$1" o="$2"
  if command -v curl >/dev/null 2>&1; then curl -fsSL --connect-timeout 10 -o "$o" "$u"
  elif command -v wget >/dev/null 2>&1; then wget -q -T 15 -O "$o" "$u"
  else return 2; fi; }
get_update_url(){ [ -n "${BN_UPDATE_URL:-}" ] && { echo "$BN_UPDATE_URL"; return; }
  [ -f "$UPDATE_CONF" ] && sed -n 's/^BN_UPDATE_URL=//p' "$UPDATE_CONF" | tr -d '"'; }
ver_gt(){ [ "$1" != "$2" ] && [ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -1)" = "$1" ]; }

write_autoupdate_units(){
  cat > "$AU_SVC" <<EOF
[Unit]
Description=BrokenNode auto-update
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/bin/env bash $SRC_DIR/BrokenNode.sh autoupdate-run
EOF
  cat > "$AU_TIMER" <<EOF
[Unit]
Description=BrokenNode auto-update timer
[Timer]
OnBootSec=10min
OnUnitActiveSec=1d
Persistent=true
[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload 2>/dev/null
}

# self_update_remote: fetch VERSION + the arch binary from the configured URL,
# verify it runs, back up the current core, install, restart. Fail-OPEN: any
# network/parse error leaves the running tunnel exactly as-is (critical during a
# blackout, when no server is reachable anyway).
self_update_remote(){
  need_root
  local url; url="$(get_update_url)"
  [ -n "$url" ] || { err "No update URL set (option: Auto-update settings)."; return 1; }
  url="${url%/}"
  local tmp; tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' RETURN
  if ! fetch "$url/VERSION" "$tmp/VERSION"; then warn "auto-update: $url unreachable — keeping current core."; return 0; fi
  local rv cv; rv="$(tr -dc '0-9.' < "$tmp/VERSION")"
  cv="$([ -x "$BIN" ] && "$BIN" version 2>/dev/null | awk '{print $NF}' | tr -dc '0-9.')"
  [ -n "$rv" ] || { warn "auto-update: bad VERSION file."; return 0; }
  if ! ver_gt "$rv" "$cv"; then info "auto-update: already current ($cv)."; return 0; fi
  info "auto-update: $cv -> $rv, downloading..."
  if ! fetch "$url/brokennode-linux-$(arch_sfx)" "$tmp/core"; then warn "auto-update: download failed — keeping current."; return 0; fi
  chmod +x "$tmp/core"
  "$tmp/core" version >/dev/null 2>&1 || { err "auto-update: downloaded core won't run — aborting."; return 1; }
  [ -x "$BIN" ] && cp -f "$BIN" "$BIN.bak"
  install -m0755 "$tmp/core" "$BIN"
  if ! "$BIN" version >/dev/null 2>&1; then err "auto-update: new core broken — rolling back."; [ -f "$BIN.bak" ] && mv -f "$BIN.bak" "$BIN"; return 1; fi
  info "auto-update: now $("$BIN" version | awk '{print $NF}')"
  restart_all_tunnels
}

autoupdate_menu(){
  need_root; banner
  local cur tstate; cur="$(get_update_url)"; tstate="$(systemctl is-enabled brokennode-autoupdate.timer 2>/dev/null || echo disabled)"
  echo; echo -e "${C_B}  Automatic (hands-off) update${C_N}"
  echo -e "  ${C_D}Checks your release URL ~daily and 10min after boot, then self-updates.${C_N}"
  echo -e "  ${C_D}The URL must serve:  VERSION  ·  brokennode-linux-amd64  ·  brokennode-linux-arm64${C_N}"
  echo -e "  ${C_D}current URL: ${cur:-(none)}    timer: $tstate${C_N}"
  echo
  echo "   1) Enable / set URL    2) Disable    3) Run now    0) Back"
  case "$(ask 'Choice' '')" in
    1) local u; u=$(ask 'Release base URL (https://...)' "$cur"); [ -z "$u" ] && { warn "no URL given"; return; }
       mkdir -p "$CFG_DIR"; printf 'BN_UPDATE_URL=%s\n' "$u" > "$UPDATE_CONF"; chmod 600 "$UPDATE_CONF"
       write_autoupdate_units; systemctl enable --now brokennode-autoupdate.timer >/dev/null 2>&1
       info "Auto-update enabled (daily)."
       warn "Note: auto-update needs internet — it can't run during a national blackout." ;;
    2) systemctl disable --now brokennode-autoupdate.timer >/dev/null 2>&1; info "Auto-update disabled." ;;
    3) self_update_remote ;;
    0) : ;;
  esac
}

# uninstall_all: remove EVERYTHING — tunnels, core, configs, passkeys, units.
uninstall_all(){
  need_root; banner
  echo
  warn "This permanently DELETES: all tunnels, the core binary, every config,"
  warn "the saved passkey, and the systemd units. This cannot be undone."
  local c; c=$(ask "Type ${C_Y}wipe${C_N} to confirm full uninstall" "")
  [ "$c" = wipe ] || { info "Cancelled — nothing removed."; return; }
  local n
  for f in "$CFG_DIR"/*.json; do [ -e "$f" ] || continue; n="$(basename "$f" .json)"; systemctl disable --now "brokennode@$n" >/dev/null 2>&1; done
  systemctl list-units --all --no-legend 2>/dev/null | grep -o 'brokennode@[^ ]*\.service' | sort -u | while read -r u; do systemctl disable --now "$u" >/dev/null 2>&1; done
  systemctl disable --now brokennode-autoupdate.timer >/dev/null 2>&1
  rm -f "$AU_SVC" "$AU_TIMER" "$TPL"
  systemctl daemon-reload 2>/dev/null; systemctl reset-failed 2>/dev/null
  rm -f "$BIN" "$BIN.bak"
  rm -rf "$CFG_DIR"
  info "BrokenNode fully removed — core, tunnels, configs and units are gone."
}

# tune_network: the biggest real throughput lever for a lossy intercontinental
# path. Enables BBR congestion control + fq qdisc and raises TCP buffer ceilings.
# Run on BOTH the Iran relay AND the foreign server. Persisted across reboots.
tune_network(){
  need_root
  banner
  echo
  echo -e "${C_B}  Network tuning for throughput${C_N}"
  echo -e "  ${C_D}Enables BBR + fq and large TCP buffers. Run on BOTH servers.${C_N}"
  modprobe tcp_bbr 2>/dev/null || true
  if ! grep -q '^tcp_bbr' /etc/modules-load.d/bbr.conf 2>/dev/null; then
    echo tcp_bbr > /etc/modules-load.d/bbr.conf
  fi
  cat > /etc/sysctl.d/99-brokennode.conf <<'EOF'
# BrokenNode network tuning
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.ipv4.tcp_rmem = 4096 87380 33554432
net.ipv4.tcp_wmem = 4096 65536 33554432
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_fastopen = 3
net.core.netdev_max_backlog = 16384
net.ipv4.tcp_slow_start_after_idle = 0
EOF
  sysctl --system >/dev/null 2>&1
  local cc qd
  cc="$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)"
  qd="$(sysctl -n net.core.default_qdisc 2>/dev/null)"
  if [ "$cc" = bbr ]; then
    info "BBR is active (congestion=$cc, qdisc=$qd). Buffers raised."
  else
    warn "Applied, but congestion control is '$cc' (kernel may lack BBR; needs Linux >= 4.9)."
  fi
  warn "Remember to run this on the OTHER server too, then restart the tunnels."
}

main_menu(){
  auto_apply_bundled
  while true; do
    banner
    echo
    echo "   1) Create SERVER tunnel   (Iran relay)"
    echo "   2) Create CLIENT tunnel   (foreign server)"
    echo "   3) Manage tunnels         (list / start / stop / logs / delete)"
    echo "   4) Transport guide"
    echo "   5) Install / update core  (from this folder)"
    echo "   6) Auto-update settings   (hands-off, from your release URL)"
    echo "   7) Network tuning         (BBR + buffers — run on both servers)"
    echo -e "   8) ${C_R}UNINSTALL everything${C_N}   (tunnels + core + all settings)"
    echo "   9) Health check           (doctor: BBR / ports / loss / IP)"
    echo "   0) Exit"
    echo -e "  ${C_D}(a newer core bundled here is applied automatically on start)${C_N}"
    echo
    case "$(ask 'Choice' '')" in
      1) create_tunnel server; read -rp "  press enter..." _ ;;
      2) create_tunnel client; read -rp "  press enter..." _ ;;
      3) manage_tunnels ;;
      4) show_transports ;;
      5) install_core; read -rp "  press enter..." _ ;;
      6) autoupdate_menu; read -rp "  press enter..." _ ;;
      7) tune_network; read -rp "  press enter..." _ ;;
      8) uninstall_all; read -rp "  press enter..." _ ;;
      9) doctor; read -rp "  press enter..." _ ;;
      0) exit 0 ;;
      *) warn "Invalid." ;;
    esac
  done
}

case "${1:-}" in
  server) create_tunnel server ;;
  client) create_tunnel client ;;
  manage) manage_tunnels ;;
  transports) ensure_core && "$BIN" -transports ;;
  install-core|build) install_core ;;
  update) update_all ;;
  autoupdate) autoupdate_menu ;;
  autoupdate-run) self_update_remote ;;
  tune|tune-network) tune_network ;;
  doctor|health|check) doctor ;;
  restart-all|start-all|stop-all)
    action="${1%-all}"
    units=""
    for f in "$CFG_DIR"/*.json; do [ -e "$f" ] || continue; n=$(basename "$f" .json); units="$units brokennode@$n"; done
    if [ -z "$units" ]; then echo "no tunnels found in $CFG_DIR"; exit 0; fi
    echo "${action}ing:$units"
    # shellcheck disable=SC2086
    systemctl "$action" $units && echo "done." ;;
  uninstall|purge) uninstall_all ;;
  version) echo "BrokenNode manager v$VERSION" ;;
  ""|menu) main_menu ;;
  *) echo "usage: sudo bash BrokenNode.sh [server|client|manage|transports|install-core|update|autoupdate|tune|restart-all|start-all|stop-all|doctor|uninstall|version]"; exit 1 ;;
esac

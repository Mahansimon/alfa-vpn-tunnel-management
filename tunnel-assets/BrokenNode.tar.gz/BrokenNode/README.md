# BrokenNode Tunnel — v1.10.2

Self-hosted multi-protocol reverse tunnel. This package ships the tunnel core
(amd64 + arm64) and the manager script. The right binary for your CPU is picked
automatically.

## Install / update

```bash
tar -xzf BrokenNode.tar.gz && cd BrokenNode
chmod +x BrokenNode.sh
sudo bash BrokenNode.sh install-core
sudo bash BrokenNode.sh
```

**Updating is automatic.** When you ship a newer package, the customer just
re-runs `sudo bash BrokenNode.sh` — on start it detects the newer bundled core,
installs it, and restarts every tunnel without touching any config. No menu
step needed.

Optional hands-off updates from your own release URL: menu → "Auto-update
settings" (sets up a daily systemd timer; needs internet, so it cannot run
during a national blackout).

## Menu

```
 1) Create SERVER tunnel   (Iran relay)
 2) Create CLIENT tunnel   (foreign server)
 3) Manage tunnels
 4) Transport guide
 5) Install / update core
 6) Auto-update settings
 7) UNINSTALL everything   (deletes tunnels + core + all settings)
```

## What changed in v1.10.2

- **BBR on the carrier sockets.** iperf3 showed the raw line does 400+ Mbit on a
  single stream but collapses to ~130 with heavy retransmits under parallel load
  — classic packet loss + cubic. The tunnel now requests BBR per-socket so
  throughput doesn't collapse on lossy paths. Run `BrokenNode.sh tune` on BOTH
  servers so the bbr module is loaded and `fq` qdisc is set.
- **Bigger copy buffer (256 KB)** for higher per-flow throughput.
- **Tunable smux windows** (`smux_recv_mb` / `smux_stream_mb`) for many-user setups.
- **Safer connection pool** (auto-scales toward the FD limit instead of a fixed cap).
- Scanner "bad token" probes no longer spam the log (moved to debug).


## Stability tip

A single link drops everything on any blip. For the smoothest experience under
Iranian conditions use **`mtcpobf` with 4 links** — when one link blips the
others keep carrying traffic.
